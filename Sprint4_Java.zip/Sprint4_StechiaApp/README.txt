====================================
STECHIAAPP - Sprint 4 (FIAP - DDD)
====================================

Integrantes:
- Lincoln Augusto Roncato – RM565944
- Natalia Souza – RM564099
- Rafael Malaguti – RM561830

Professor: Gilberto Alexandre das Neves
Turma: 1TDSR


1. Descrição do Projeto

O StechiaApp é um sistema em Java com Quarkus e Oracle Database, voltado ao agendamento e confirmação de consultas médicas, com foco em acessibilidade digital.


2. Execução

Pré-requisitos:
- Java 21
- Maven 3.9+
- Oracle Database 21c XE

Comandos:
mvn clean package
mvn quarkus:dev
ou
java -jar target/StechiaApp-1.0.0-SNAPSHOT-runner.jar


3. Banco de Dados

Executar o script /src/main/resources/db/ddl.sql no Oracle SQL Developer.


4. Testes da API

Importar o JSON do Insomnia (pasta /insomnia) e testar os endpoints:
http://localhost:8080/pacientes
http://localhost:8080/consultas


5. Observações

Projeto completo e funcional para entrega da Sprint 4 da disciplina Domain Driven Design Using Java.
